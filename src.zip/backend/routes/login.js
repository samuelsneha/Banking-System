const express = require('express');
const router = express.Router();

router.post('/', [
        body('email', 'Enter a valid email').isEmail(),
        body('password', 'Password must be atleast 5 characters').isLength({ min:5}),
    ] , async (req,res) => { 
        //if the above validations are not satisfied then we create errors 
        const errors = validationResult(req);
        if(!errors.isEmpty()){
          return res.status(400).json({errors: errors.array()});  
        }
        //if the above validations are satisfied 
        const {email, password} = req.body;
        try{
                

        }catch{

        }

    }    

module.exports = router;